/* ===== PKI Masterpiece — dashboard.js ===== */

// ─── Theme toggle ─────────────────────────────────────────────────────────────
function initTheme() {
  const saved = localStorage.getItem('pki-theme') || 'dark';
  if (saved === 'light') document.body.classList.add('light-mode');
  updateToggleBtn();
}

function toggleTheme() {
  document.body.classList.toggle('light-mode');
  const theme = document.body.classList.contains('light-mode') ? 'light' : 'dark';
  localStorage.setItem('pki-theme', theme);
  updateToggleBtn();
  toast(theme === 'light' ? '☀️ Mode clair activé' : '🌙 Mode sombre activé', 'info');
}

function updateToggleBtn() {
  const btn = document.getElementById('theme-btn');
  if (!btn) return;
  const light = document.body.classList.contains('light-mode');
  btn.textContent = light ? '🌙 Dark' : '☀️ Light';
}

// ─── Toast notifications ───────────────────────────────────────────────────────
function toast(msg, type = 'info', duration = 3500) {
  const container = document.getElementById('toast-container');
  if (!container) return;

  const icons = { info: 'ℹ️', success: '✅', warn: '⚠️', error: '❌' };
  const colors = { info: '#4FACFE', success: '#00D4AA', warn: '#F0B90B', error: '#FF3B30' };

  const el = document.createElement('div');
  el.className = 'toast-pki';
  el.style.borderColor = colors[type] || colors.info;
  el.innerHTML = `
    <span style="font-size:1.1rem">${icons[type] || icons.info}</span>
    <span>${msg}</span>
  `;
  container.appendChild(el);
  setTimeout(() => {
    el.style.opacity = '0';
    el.style.transform = 'translateX(40px)';
    el.style.transition = '.3s';
    setTimeout(() => el.remove(), 300);
  }, duration);
}

// ─── Animated KPI counters ─────────────────────────────────────────────────────
function animateCounters() {
  document.querySelectorAll('.kpi-number[data-target]').forEach(el => {
    const target = parseInt(el.dataset.target);
    let cur = 0;
    const step = Math.max(1, target / 40);
    const t = setInterval(() => {
      cur += step;
      if (cur >= target) { el.textContent = target; clearInterval(t); }
      else el.textContent = Math.round(cur);
    }, 25);
  });
}

// ─── Live console refresh ──────────────────────────────────────────────────────
function startLiveConsole() {
  setInterval(async () => {
    try {
      const r = await fetch('/api/logs');
      const logs = await r.json();
      const c = document.getElementById('console');
      if (c && logs.length) {
        c.innerHTML = logs.map(l =>
          `<div class="log-${l.severity}">[${l.created_at}] ${l.action}${l.target ? ' → ' + l.target : ''}</div>`
        ).join('');
      }
    } catch (e) { /* silently fail */ }
  }, 5000);
}

// ─── Parallax on scroll ────────────────────────────────────────────────────────
function initParallax() {
  window.addEventListener('scroll', () => {
    const y = window.scrollY;
    document.querySelectorAll('.card').forEach((card, i) => {
      const speed = 0.02 + (i % 3) * 0.01;
      card.style.transform = `translateY(${y * speed}px)`;
    });
  }, { passive: true });
}

// ─── Presentation mode (press P) ──────────────────────────────────────────────
function initPresentationMode() {
  document.addEventListener('keydown', e => {
    if (e.key === 'p' || e.key === 'P') {
      const navbar = document.querySelector('.navbar');
      const alerts = document.querySelectorAll('.alert');
      if (document.body.classList.contains('presentation-mode')) {
        document.body.classList.remove('presentation-mode');
        if (navbar) navbar.style.display = '';
        alerts.forEach(a => a.style.display = '');
        toast('Mode présentation désactivé', 'info');
      } else {
        document.body.classList.add('presentation-mode');
        if (navbar) navbar.style.display = 'none';
        alerts.forEach(a => a.style.display = 'none');
        toast('Mode présentation activé — appuyez P pour quitter', 'info', 4000);
      }
    }
    // ESC to exit presentation mode
    if (e.key === 'Escape' && document.body.classList.contains('presentation-mode')) {
      document.body.classList.remove('presentation-mode');
      const navbar = document.querySelector('.navbar');
      if (navbar) navbar.style.display = '';
    }
  });
}

// ─── Init ──────────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  initTheme();
  animateCounters();
  startLiveConsole();
  initPresentationMode();
  // Parallax only on desktop
  if (window.innerWidth > 768) initParallax();
});
