import sqlite3
from datetime import date, timedelta
from pathlib import Path

DB_PATH = Path(__file__).parent.parent / "pki_masterpiece.db"


def get_db():
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with get_db() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS certificates (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            cn TEXT NOT NULL,
            serial TEXT UNIQUE,
            san TEXT DEFAULT '',
            type_cert TEXT DEFAULT 'server',
            key_algo TEXT DEFAULT 'rsa',
            key_size INTEGER DEFAULT 2048,
            status TEXT DEFAULT 'valid',
            cert_path TEXT,
            sign_ms REAL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            expires_at DATETIME,
            revoked_at DATETIME,
            rev_reason TEXT
        );
        CREATE TABLE IF NOT EXISTS audit_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            action TEXT NOT NULL,
            target TEXT,
            ip TEXT,
            details TEXT,
            severity TEXT DEFAULT 'info',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );
        """)
        db.commit()


def log_action(action, target=None, ip=None, details=None, severity='info'):
    with get_db() as db:
        db.execute(
            "INSERT INTO audit_logs (action,target,ip,details,severity) VALUES (?,?,?,?,?)",
            (action, target, ip, details, severity)
        )
        db.commit()


def get_stats():
    with get_db() as db:
        total   = db.execute("SELECT COUNT(*) FROM certificates").fetchone()[0]
        valid   = db.execute("SELECT COUNT(*) FROM certificates WHERE status='valid'").fetchone()[0]
        revoked = db.execute("SELECT COUNT(*) FROM certificates WHERE status='revoked'").fetchone()[0]
        expired = db.execute("SELECT COUNT(*) FROM certificates WHERE status='expired'").fetchone()[0]
        ms_row  = db.execute("SELECT AVG(sign_ms) FROM certificates WHERE sign_ms IS NOT NULL").fetchone()[0]
        logs    = db.execute("SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT 20").fetchall()
    health = max(0, int(100 - (revoked + expired) / max(total, 1) * 50))
    return {
        'total': total, 'valid': valid, 'revoked': revoked,
        'expired': expired, 'health': health,
        'avg_sign_ms': round(ms_row or 0, 1),
        'logs': [dict(l) for l in logs]
    }


def get_advanced_stats():
    with get_db() as db:
        total = db.execute("SELECT COUNT(*) FROM certificates").fetchone()[0]
        revoked = db.execute("SELECT COUNT(*) FROM certificates WHERE status='revoked'").fetchone()[0]
        ms_row = db.execute("SELECT AVG(sign_ms) FROM certificates WHERE sign_ms IS NOT NULL").fetchone()[0]

        # Expiring in 7 days
        expiring = db.execute("""
            SELECT COUNT(*) FROM certificates
            WHERE status='valid'
            AND expires_at IS NOT NULL
            AND date(expires_at) <= date('now','+7 days')
            AND date(expires_at) >= date('now')
        """).fetchone()[0]

        # Signs per day avg
        signs_per_day = db.execute("""
            SELECT AVG(cnt) FROM (
                SELECT COUNT(*) as cnt FROM certificates
                WHERE created_at >= date('now','-30 days')
                GROUP BY date(created_at)
            )
        """).fetchone()[0]

        # Peak day
        peak = db.execute("""
            SELECT date(created_at) as day, COUNT(*) as cnt
            FROM certificates
            WHERE created_at >= date('now','-30 days')
            GROUP BY day ORDER BY cnt DESC LIMIT 1
        """).fetchone()

    return {
        'total_signs': total,
        'avg_sign_time_ms': round(ms_row or 0, 1),
        'expiring_in_7_days': expiring,
        'revocation_rate': round(revoked / max(total, 1) * 100, 1),
        'avg_signs_per_day': round(signs_per_day or 0, 1),
        'peak_day': peak['day'] if peak else '—',
        'peak_day_count': peak['cnt'] if peak else 0,
    }


def get_chart_data():
    with get_db() as db:
        rows = db.execute("""
            SELECT date(created_at) as day, COUNT(*) as cnt
            FROM certificates
            WHERE created_at >= date('now','-30 days')
            GROUP BY day ORDER BY day
        """).fetchall()
    base = {}
    for i in range(30):
        d = (date.today() - timedelta(days=29 - i)).isoformat()
        base[d] = 0
    for r in rows:
        base[r['day']] = r['cnt']
    return list(base.keys()), list(base.values())
