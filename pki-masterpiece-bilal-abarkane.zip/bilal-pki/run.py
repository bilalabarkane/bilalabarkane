#!/usr/bin/env python3
import os
from pathlib import Path

env_file = Path(__file__).parent / ".env"
if env_file.exists():
    for line in env_file.read_text().splitlines():
        line = line.strip()
        if line and not line.startswith('#') and '=' in line:
            k, v = line.split('=', 1)
            os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))

from app.app import app

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    debug = os.environ.get('FLASK_DEBUG', '1') == '1'
    print(f"\n🔐 PKI Masterpiece — http://localhost:{port}")
    print(f"   Vue 3D       — http://localhost:{port}/viz\n")
    app.run(host='0.0.0.0', port=port, debug=debug)
