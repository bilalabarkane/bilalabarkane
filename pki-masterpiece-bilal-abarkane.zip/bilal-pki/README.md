# 🔐 PKI Masterpiece

Infrastructure à Clés Publiques complète avec dashboard web Flask et visualisation 3D.

## 📁 Arborescence du projet

```
pki-masterpiece/
├── .env                          # Variables d'environnement (mots de passe CA)
├── requirements.txt              # Dépendances Python
├── run.py                        # Point d'entrée Flask
├── config/
│   ├── root.cnf                  # Config OpenSSL Root CA
│   └── inter.cnf                 # Config OpenSSL Intermediate CA
├── scripts/
│   ├── init_ca.sh                # Initialisation PKI (Root + Inter + CRL)
│   ├── gen_csr.sh                # Génération clé + CSR avec SAN
│   ├── sign_cert.sh              # Signature par Intermediate CA
│   ├── revoke.sh                 # Révocation + mise à jour CRL
│   ├── verify.sh                 # Vérification 5/5 (score)
│   └── demo.sh                   # Démonstration complète automatisée
├── pki/
│   ├── root/                     # Root CA (privée, auto-signée, 20 ans)
│   ├── intermediate/             # Intermediate CA (signée par Root, 10 ans)
│   └── leaf/                     # Certificats finaux (serveur/client)
├── app/
│   ├── app.py                    # Routes Flask (7 routes + 5 API)
│   ├── models.py                 # SQLite (certificats + audit_logs)
│   ├── crypto_utils.py           # Cryptographie Python (OpenSSL wrapper)
│   ├── static/
│   │   ├── css/dashboard.css     # CSS premium dark/light
│   │   └── js/dashboard.js       # Toasts, parallax, compteurs, thème
│   └── templates/
│       ├── base.html             # Template de base avec navbar
│       ├── dashboard.html        # KPIs + graphiques Chart.js
│       ├── generate.html         # Génération CSR RSA/ECDSA
│       ├── sign.html             # Signature de certificats
│       ├── list.html             # Liste + révocation avec modal
│       ├── verify.html           # Vérification 5 critères
│       └── viz.html              # Visualisation 3D Three.js
└── logs/
    └── pki.log                   # Journal des opérations
```

## 🚀 Installation et lancement

```bash
# 1. Dépendances système
sudo apt update && sudo apt install -y openssl python3 python3-pip python3-venv

# 2. Environnement virtuel
cd ~/pki-masterpiece
python3 -m venv venv && source venv/bin/activate
pip install flask cryptography

# 3. Initialiser la PKI
bash scripts/init_ca.sh

# 4. Démonstration complète (optionnel)
bash scripts/demo.sh

# 5. Lancer le dashboard
python3 run.py
```

Accéder à : `http://localhost:5000` | Vue 3D : `http://localhost:5000/viz`

## 📋 Commandes PKI

```bash
# Générer une CSR (RSA)
bash scripts/gen_csr.sh "mon-site.com" "www.mon-site.com,api.mon-site.com" rsa 2048

# Générer une CSR (ECDSA P-384)
bash scripts/gen_csr.sh "mon-site.com" "" ecdsa 384

# Signer un certificat
bash scripts/sign_cert.sh "mon-site.com" server 365

# Vérifier un certificat (score /5)
bash scripts/verify.sh pki/leaf/certs/mon-site_com.crt.pem

# Révoquer + mettre à jour CRL
bash scripts/revoke.sh pki/leaf/certs/mon-site_com.crt.pem keyCompromise

# API statistiques avancées
curl http://localhost:5000/api/advanced-stats
```

## 🛡️ Justifications NIST

| Choix technique | Justification NIST |
|---|---|
| **RSA 4096** pour les CA | NIST SP 800-57 : RSA ≥ 2048 requis, 4096 pour Root/Inter CA longue durée |
| **ECDSA P-384** disponible | NIST FIPS 186-4 : P-384 offre 192 bits de sécurité, recommandé post-2030 |
| **SHA-256** exclusif | NIST SP 800-131A : SHA-1 interdit depuis 2016, SHA-256 minimum requis |
| **Chaîne à 3 niveaux** | Bonne pratique PKI : isolation Root CA hors ligne, Intermediate pour émission |
| **pathlen:1** sur Root CA | RFC 5280 : limite la profondeur de la chaîne, réduit la surface d'attaque |
| **CRL** mise à jour | RFC 5280 : révocation obligatoire, CRL signée et horodatée |
| **SAN** obligatoires | RFC 2818 / CA/Browser Forum : CN seul déprécié depuis 2017 |
| **rand_serial=yes** | NIST SP 800-57 : numéros de série imprévisibles, évite les collisions |
| **chmod 400/600** clés | Contrôle d'accès : clés privées non lisibles par autres utilisateurs |
| **Validité 365 jours max** | CA/Browser Forum Baseline Requirements : max 398 jours |

## 🌐 Routes Flask

| Route | Méthode | Description |
|---|---|---|
| `/` | GET | Dashboard avec KPIs, graphiques, console |
| `/generate` | GET/POST | Génération CSR RSA ou ECDSA |
| `/sign` | GET/POST | Signature d'une CSR uploadée |
| `/certificates` | GET | Liste avec filtres et recherche |
| `/revoke/<id>` | POST | Révocation + raison + CRL update |
| `/verify` | GET/POST | Vérification 5 critères avec score |
| `/viz` | GET | Visualisation 3D Three.js |
| `/api/graph-data` | GET | Données graphe JSON pour Three.js |
| `/api/stats` | GET | Statistiques JSON |
| `/api/advanced-stats` | GET | Statistiques avancées |
| `/api/logs` | GET | 5 dernières actions audit |
| `/download/crl` | GET | Télécharger la CRL |
| `/download/chain` | GET | Télécharger la chaîne |

## 📊 Captures d'écran à prendre

1. `http://localhost:5000` — Dashboard complet
2. `http://localhost:5000/viz` — Vue 3D chaîne de confiance
3. `http://localhost:5000/generate` — Génération CSR
4. `http://localhost:5000/sign` — Signature
5. `http://localhost:5000/certificates` — Liste certificats
6. `http://localhost:5000/verify` — Score 5/5
7. Touche P sur le dashboard — Mode présentation
8. Terminal : `bash scripts/demo.sh`

## ✅ Conformité au sujet

| Exigence | Statut |
|---|---|
| PKI 3 niveaux (Root, Inter, Leaf) | ✅ |
| Root CA auto-signée RSA 4096 | ✅ |
| Intermediate CA signée par Root | ✅ |
| CSR avec SAN | ✅ |
| Signature par CA parente | ✅ |
| Révocation + CRL | ✅ |
| Vérification 5/5 | ✅ |
| Interface web Flask | ✅ |
| Sécurisation des clés | ✅ |
| Justifications NIST | ✅ |
| Visualisation 3D | ✅ (bonus) |
| Dark/Light mode | ✅ (bonus) |
| Statistiques avancées API | ✅ (bonus) |
