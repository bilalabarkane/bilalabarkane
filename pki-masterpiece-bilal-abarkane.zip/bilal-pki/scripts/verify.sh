#!/usr/bin/env bash
set -euo pipefail
RED='\033[0;31m';GRN='\033[0;32m';YLW='\033[1;33m';BOLD='\033[1m';NC='\033[0m'
ok(){   echo -e "${GRN}  ✔ $*${NC}"; ((SCORE++)); }
fail(){ echo -e "${RED}  ✘ $*${NC}"; }

CERT="${1:?Usage: verify.sh <cert>}"
[[ -f "$CERT" ]] || { echo -e "${RED}Introuvable: $CERT${NC}"; exit 1; }

SD="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
RD="$(cd "$SD/.." && pwd)"
CHAIN="$RD/pki/intermediate/certs/chain.crt.pem"
CRL="$RD/pki/intermediate/crl/inter.crl.pem"
SCORE=0; MAX=5

echo -e "\n${BOLD}━━ Vérification : $(basename "$CERT") ━━${NC}\n"

openssl x509 -in "$CERT" -noout 2>/dev/null \
    && ok "Format X.509 valide" || { fail "Format invalide"; exit 1; }

openssl x509 -in "$CERT" -noout -checkend 0 2>/dev/null \
    && ok "Dates valides" || fail "EXPIRÉ"

[[ -f "$CHAIN" ]] && {
    (cd "$RD" && openssl verify -CAfile "$CHAIN" "$CERT" &>/dev/null) \
        && ok "Chaîne Root→Inter→Leaf valide" || fail "Chaîne invalide"
}

[[ -f "$CRL" ]] && {
    R=$( (cd "$RD" && openssl verify -CAfile "$CHAIN" \
        -CRLfile "$CRL" -crl_check "$CERT") 2>&1 || true )
    echo "$R" | grep -q "revoked" \
        && fail "RÉVOQUÉ dans la CRL" || ok "Non révoqué (CRL vérifiée)"
}

TEXT=$(openssl x509 -in "$CERT" -noout -text 2>/dev/null)
echo "$TEXT" | grep -qi "sha1WithRSA" \
    && fail "SHA-1 obsolète" || ok "Algorithme moderne (SHA-256+)"

PCT=$(( SCORE * 100 / MAX ))
echo ""
if [[ $SCORE -eq $MAX ]]; then
    echo -e "${BOLD}${GRN}Score : $SCORE/$MAX (${PCT}%) ✅ PARFAIT${NC}"
elif [[ $SCORE -ge 3 ]]; then
    echo -e "${BOLD}${YLW}Score : $SCORE/$MAX (${PCT}%) ⚠ ATTENTION${NC}"
else
    echo -e "${BOLD}${RED}Score : $SCORE/$MAX (${PCT}%) ❌ INVALIDE${NC}"
fi
